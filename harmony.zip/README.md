# Harmony is currently in very early Alpha and is missing basic features. Feel free to contribute

# Harmony
A matrix client based on the look of classic Discord.

# Running Harmony Client (for testing purposes)
Install the required dependencies
```
npm install
```
Run Harmony
```
npm start
```
Builds will be provided upon Alpha Release
